from django.contrib import admin
from .models import Accounts,CustomerAccount

admin.site.register(Accounts)
admin.site.register(CustomerAccount)
# Register your models here.
